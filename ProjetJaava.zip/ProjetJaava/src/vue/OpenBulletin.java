package vue;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;

import controleur.Controleur;

public class OpenBulletin extends JPanel {
	
	JPanel panel = new JPanel(false);
	JPanel main = new JPanel(false);
	JPanel panelN = new JPanel(false);
	JPanel panelC = new JPanel(false);
	 
	JLabel errLabel = new JLabel("PatchNote 9.69 Rito Games!");
	 
	JButton addEvalButton = new JButton("Ajouter une evaluation");
	
	Controleur controleur = new Controleur();
	/**
         * Constructeur qui instancie l'ouverture du bulletin
         * @param fenetre
         * @param idBulletin 
         */
	public OpenBulletin(JDialog fenetre, int idBulletin) {
		
		 TablePanelUnBulletin tablePanel;
		 tablePanel = new TablePanelUnBulletin();
		 tablePanel.setData(controleur.rechercheUnBulletin(idBulletin));
		 tablePanel.rafraichir();
		 
		 panelN.setLayout(new FlowLayout());
		 panelN.add(addEvalButton);
		 
		 main.setLayout(new BorderLayout());
		 main.add(panelN, BorderLayout.NORTH);
		 main.add(new JScrollPane(tablePanel), BorderLayout.CENTER);
		 
		 addEvalButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				AddEval addEval;
				JDialog addEvalWindo = new JDialog();
				addEval = new AddEval(idBulletin, addEvalWindo, tablePanel);
				
				addEvalWindo.setLayout(new FlowLayout());
				addEvalWindo.add(addEval.getPanel());
				addEvalWindo.setTitle("Donnez nous 20/20 SVP");
				addEvalWindo.setSize(600, 400);
				addEvalWindo.setVisible(true);
				
			}
		});
		
	}
	
	
	public JPanel getPanel() {
		return main;
	}
}
