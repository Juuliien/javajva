package modele;

public class UnBulletin {

	private int note;
	private String matiere;
	private String appreciationEval;
	private String appreciationMatiere;
	
	public UnBulletin(){
		
	}
	
	public int getNote() {
		return note;
	}
	public void setNote(int note) {
		this.note = note;
	}
	public String getMatiere() {
		return matiere;
	}
	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	public String getAppreciationEval() {
		return appreciationEval;
	}
	public void setAppreciationEval(String appreciationEval) {
		this.appreciationEval = appreciationEval;
	}
	public String getAppreciationMatiere() {
		return appreciationMatiere;
	}
	public void setAppreciationMatiere(String appreciationMatiere) {
		this.appreciationMatiere = appreciationMatiere;
	}
	
	
	
}
